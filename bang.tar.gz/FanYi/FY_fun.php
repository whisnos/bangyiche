<?php
include_once('../FY_fun/FY_fun.PHP');
define('F_HT',F_ML."FanYi/");





?>