<?php
include_once("FY_fun.php");
echo "true";
$_SESSION['SU_id']=$_SESSION['SU_id'];

if(isset($_SESSION)){ }






?>