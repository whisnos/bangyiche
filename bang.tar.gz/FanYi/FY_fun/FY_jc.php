<?php //后台类目录
define("MY_db","127.0.0.1:usr:psaa:sql");//数据库链接函数
define("FY_aq","sa");//登录安全码


?>