<div class="footer">
	<h3><a href="javascript:;" id="backtop">返回顶部</a></h3>
<?php  $ab=$DB->Sels("lr","a_dy","id=9","",""); echo FF($ab[0],0); ?>
</div>

<div class="down">
	<ul>
    	<li><a href="index.php">网站首页</a></li>
        <li><a href="cp.php">产品中心</a></li>
        <li><a href="about.php">关于我们</a></li>
        <li><a href="lx.php">联系我们</a></li>
    </ul>
</div>

</body>
</html>
